package interfaces;

public abstract interface YouTuber {

	abstract void makeVideo();

}
