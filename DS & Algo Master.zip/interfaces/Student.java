package interfaces;

public abstract interface Student {

	abstract void study();

}
